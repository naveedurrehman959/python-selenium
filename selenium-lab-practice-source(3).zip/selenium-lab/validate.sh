#!/usr/bin/env bash
set -uo pipefail
cd "$(dirname "$0")"
pass=0
fail=0

check() {
  local description="$1"; shift
  if "$@" >/dev/null 2>&1; then
    echo "PASS  $description"
    pass=$((pass + 1))
  else
    echo "FAIL  $description"
    fail=$((fail + 1))
  fi
}

check "Compose configuration is valid" docker compose config -q
check "TaskBoard application source compiles" python3 -m py_compile app/app.py
check "Framework source compiles" python3 -m compileall -q framework
check "CSV has six data cases" bash -c 'test "$(($(wc -l < framework/data/login_cases.csv)-1))" -eq 6'
check "CI script is executable" test -x run_ci.sh
check "Validation script is executable" test -x validate.sh

if curl -fsS http://localhost:5000/healthz >/dev/null 2>&1; then
  check "TaskBoard health endpoint" bash -c '[ "$(curl -fsS http://localhost:5000/healthz)" = ok ]'
else
  echo "SKIP  Running-stack checks (start with docker compose up -d)"
fi

if curl -fsS http://localhost:4444/status >/dev/null 2>&1; then
  check "Selenium Grid reports ready" bash -c 'curl -fsS http://localhost:4444/status | jq -e ".value.ready"'
else
  echo "SKIP  Grid checks (start the Compose stack)"
fi

echo "--------------------------------------"
echo "Passed: $pass   Failed: $fail"
[[ "$fail" -eq 0 ]]
