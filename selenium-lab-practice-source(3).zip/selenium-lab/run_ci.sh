#!/usr/bin/env bash
# Start stack -> wait for Grid -> smoke gate -> selected browser suite(s) -> summary.
set -euo pipefail
cd "$(dirname "$0")"
export HOST_UID="$(id -u)" HOST_GID="$(id -g)"

read -r -a BROWSER_LIST <<< "${BROWSERS:-chrome firefox}"
if ((${#BROWSER_LIST[@]} == 0)); then
  echo "BROWSERS must contain chrome and/or firefox." >&2
  exit 2
fi
for browser in "${BROWSER_LIST[@]}"; do
  case "$browser" in
    chrome|firefox) ;;
    *) echo "Unsupported browser '$browser'. Use chrome and/or firefox." >&2; exit 2 ;;
  esac
done

echo "==> Starting stack"
docker compose up -d --build webapp selenium-hub chrome firefox
docker compose build tests

echo "==> Waiting for Selenium Grid (2 nodes)"
ready=0
for i in $(seq 1 60); do
  if curl -sf http://localhost:4444/status |
      jq -e '.value.ready and (.value.nodes | length) == 2' >/dev/null; then
    ready=1
    break
  fi
  sleep 2
done
if [[ "$ready" -ne 1 ]]; then
  echo "Grid did not become ready" >&2
  docker compose logs --tail=30 selenium-hub chrome firefox >&2
  exit 2
fi
echo "Grid ready"

mkdir -p artifacts/ci
rm -f artifacts/ci/*

smoke_browser="${BROWSER_LIST[0]}"
echo "==> Smoke gate ($smoke_browser)"
if ! docker compose run --rm -e BROWSER="$smoke_browser" tests -m smoke -q \
    --junitxml=/tests/artifacts/junit-smoke.xml; then
  echo "Smoke gate failed - skipping full suite" >&2
  exit 1
fi

rc=0
for browser in "${BROWSER_LIST[@]}"; do
  echo "==> Full suite on $browser"
  docker compose run --rm -e BROWSER="$browser" tests -n 2 -q \
    --html="/tests/artifacts/report-$browser.html" --self-contained-html \
    --junitxml="/tests/artifacts/junit-$browser.xml" || rc=$?
done

echo
echo "==> Test summary"
python3 - <<'PY'
import os
import xml.etree.ElementTree as ET
from pathlib import Path

browsers = os.environ.get("BROWSERS", "chrome firefox").split()
print(f"{'Browser':<12} {'Tests':>8} {'Failures':>10} {'Errors':>8} {'Skipped':>9}")
print("-" * 51)
for browser in browsers:
    path = Path("artifacts/ci") / f"junit-{browser}.xml"
    if not path.exists():
        print(f"{browser:<12} {'MISSING':>8} {'-':>10} {'-':>8} {'-':>9}")
        continue
    root = ET.parse(path).getroot()
    suite = root if root.tag == "testsuite" else root.find("testsuite")
    if suite is None:
        suites = root.find("testsuites")
        suite = suites
    tests = int(suite.get("tests", 0))
    failures = int(suite.get("failures", 0))
    errors = int(suite.get("errors", 0))
    skipped = int(suite.get("skipped", 0))
    print(f"{browser:<12} {tests:>8} {failures:>10} {errors:>8} {skipped:>9}")
PY

echo "==> Pipeline finished with exit code $rc"
exit "$rc"
