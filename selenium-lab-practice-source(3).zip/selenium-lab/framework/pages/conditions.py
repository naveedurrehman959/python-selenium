class row_count_is:
    """Wait condition returning matching elements when exactly n are present."""

    def __init__(self, locator, n):
        self.locator = locator
        self.expected_count = n

    def __call__(self, driver):
        elements = driver.find_elements(*self.locator)
        return elements if len(elements) == self.expected_count else False
