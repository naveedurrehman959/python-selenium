import csv
from pathlib import Path

import pytest
from pages.login_page import LoginPage

DATA_FILE = Path(__file__).parents[1] / "data" / "login_cases.csv"


def _load_cases():
    with DATA_FILE.open(newline="", encoding="utf-8") as stream:
        rows = list(csv.DictReader(stream))
    cases = []
    for row in rows:
        username = row["username"]
        password = row["password"]
        expected = row["expected"]
        readable_id = f"{username.strip() or 'empty-user'}-{expected}"
        if username != username.strip():
            readable_id = f"whitespace-user-{expected}"
        cases.append((username, password, expected, readable_id))
    return cases


@pytest.mark.parametrize(
    "username,password,expected",
    [(u, p, e) for u, p, e, _ in _load_cases()],
    ids=[case_id for _, _, _, case_id in _load_cases()],
)
def test_login_data_cases(driver, base_url, username, password, expected):
    page = LoginPage(driver, base_url).open()
    if expected == "ok":
        tasks = page.login_as(username, password)
        assert driver.current_url.endswith("/tasks")
        assert tasks.heading() == "My Tasks"
    else:
        page.login_expecting_error(username, password)
        assert page.error_text() == "Invalid username or password"
        assert driver.current_url.endswith("/login")
