import os
import pathlib
import re

import pytest
from selenium import webdriver
from selenium.webdriver.chrome.options import Options as ChromeOptions
from selenium.webdriver.firefox.options import Options as FirefoxOptions

ARTIFACTS = pathlib.Path(os.getenv("ARTIFACTS_DIR", "artifacts"))


def pytest_addoption(parser):
    parser.addoption("--browser", default=os.getenv("BROWSER", "chrome"),
                     choices=["chrome", "firefox"])
    parser.addoption("--grid-url", default=os.getenv("GRID_URL", "http://localhost:4444"))
    parser.addoption("--app-url", default=os.getenv("APP_URL", "http://webapp:5000"))


def _options(browser):
    if browser == "chrome":
        options = ChromeOptions()
        options.add_argument("--window-size=1280,900")
    else:
        options = FirefoxOptions()
        options.add_argument("--width=1280")
        options.add_argument("--height=900")
    return options


@pytest.fixture(scope="session")
def browser_name(request):
    return request.config.getoption("--browser")


@pytest.fixture(scope="session")
def base_url(request):
    return request.config.getoption("--app-url").rstrip("/")


@pytest.fixture
def driver(request, browser_name):
    drv = webdriver.Remote(
        command_executor=request.config.getoption("--grid-url"),
        options=_options(browser_name),
    )
    drv.implicitly_wait(0)
    yield drv
    drv.quit()


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    """Save a screenshot and DOM snapshot when a test body fails."""
    outcome = yield
    report = outcome.get_result()
    if report.when != "call" or not report.failed:
        return

    drv = item.funcargs.get("driver")
    if drv is None:
        return

    ARTIFACTS.mkdir(parents=True, exist_ok=True)
    browser = item.config.getoption("--browser")
    safe_name = re.sub(r"[^A-Za-z0-9_.-]", "_", item.name)
    png = ARTIFACTS / f"FAILED_{browser}_{safe_name}.png"
    html = ARTIFACTS / f"FAILED_{browser}_{safe_name}.html"

    try:
        drv.save_screenshot(str(png))
        html.write_text(drv.page_source, encoding="utf-8")
        import pytest_html
        extras = getattr(report, "extras", [])
        extras.append(pytest_html.extras.png(
            drv.get_screenshot_as_base64(), "failure screenshot"
        ))
        extras.append(pytest_html.extras.url(drv.current_url, "page URL"))
        report.extras = extras
    except Exception as exc:  # preserve the original test failure if artifact capture fails
        report.sections.append(("failure artifact capture", str(exc)))
