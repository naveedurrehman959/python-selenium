#!/usr/bin/env bash
# Speak the W3C WebDriver HTTP protocol directly (requires curl and jq).
set -euo pipefail
GRID_URL="${GRID_URL:-http://localhost:4444}"
SID="$(curl -fsS -X POST "$GRID_URL/session" \
  -H 'Content-Type: application/json' \
  -d '{"capabilities":{"alwaysMatch":{"browserName":"chrome"}}}' | jq -r '.value.sessionId')"
cleanup() {
  if [[ -n "${SID:-}" && "$SID" != "null" ]]; then
    curl -sS -X DELETE "$GRID_URL/session/$SID" >/dev/null || true
  fi
}
trap cleanup EXIT

echo "Session: $SID"
curl -fsS -X POST "$GRID_URL/session/$SID/url" \
  -H 'Content-Type: application/json' \
  -d '{"url":"http://webapp:5000/"}'
echo
curl -fsS "$GRID_URL/session/$SID/title" | jq .
curl -fsS -X POST "$GRID_URL/session/$SID/element" \
  -H 'Content-Type: application/json' \
  -d '{"using":"css selector","value":"h1"}' | jq .
