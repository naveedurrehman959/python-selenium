#!/usr/bin/env bash
# Delete any active sessions currently registered on this Grid.
set -euo pipefail
GRID_URL="${GRID_URL:-http://localhost:4444}"
mapfile -t sessions < <(
  curl -fsS "$GRID_URL/status" |
  jq -r '.value.nodes[].slots[] | select(.session != null) | .session.sessionId'
)
if ((${#sessions[@]} == 0)); then
  echo "No active sessions."
  exit 0
fi
for sid in "${sessions[@]}"; do
  echo "Deleting session $sid"
  curl -sS -X DELETE "$GRID_URL/session/$sid"
  echo
done
