"""Deliberately forget driver.quit() to simulate a leaked Grid session."""
import os
from selenium import webdriver
from selenium.webdriver.chrome.options import Options

driver = webdriver.Remote(
    command_executor=os.getenv("GRID_URL", "http://localhost:4444"),
    options=Options(),
)
driver.get(os.getenv("APP_URL", "http://webapp:5000") + "/")
print("leaked session:", driver.session_id)
# Intentionally no driver.quit(): use only for the leak-cleanup exercise.
