"""Demonstrate a custom WebDriverWait condition."""
import os

from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait

GRID_URL = os.getenv("GRID_URL", "http://localhost:4444")
APP_URL = os.getenv("APP_URL", "http://webapp:5000")


def main():
    driver = webdriver.Remote(command_executor=GRID_URL, options=Options())
    try:
        driver.get(f"{APP_URL}/login")
        driver.find_element(By.ID, "username").send_keys("admin")
        driver.find_element(By.ID, "password").send_keys("s3cret")
        driver.find_element(By.ID, "login-btn").click()
        WebDriverWait(driver, 10).until(
            lambda drv: drv.current_url.endswith("/tasks")
        )
        driver.find_element(By.ID, "load-stats").click()
        condition = lambda drv: drv.find_element(
            By.ID, "stats"
        ).text.startswith("Total tasks:")
        WebDriverWait(driver, 10).until(condition)
        print("custom wait ok:", driver.find_element(By.ID, "stats").text)
    finally:
        driver.quit()


if __name__ == "__main__":
    main()
