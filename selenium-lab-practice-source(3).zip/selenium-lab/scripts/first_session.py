"""Open a remote browser session, inspect capabilities and save a screenshot."""
import os
from pathlib import Path

from selenium import webdriver
from selenium.webdriver.chrome.options import Options as ChromeOptions

GRID_URL = os.getenv("GRID_URL", "http://localhost:4444")
APP_URL = os.getenv("APP_URL", "http://webapp:5000")
OUT = Path("artifacts")
OUT.mkdir(exist_ok=True)

options = ChromeOptions()
options.add_argument("--window-size=1280,900")
driver = webdriver.Remote(command_executor=GRID_URL, options=options)
try:
    capabilities = driver.capabilities
    print("session id :", driver.session_id)
    print("browser    :", capabilities["browserName"], capabilities["browserVersion"])
    print("platform   :", capabilities.get("platformName"))
    driver.get(f"{APP_URL}/")
    print("title      :", driver.title)
    print("url        :", driver.current_url)
    driver.save_screenshot(str(OUT / "home.png"))
    print("screenshot :", OUT / "home.png")
finally:
    driver.quit()
