# Python Selenium: Cross-Browser UI Test Automation on a Headless Selenium Grid

A complete practical lab for learning Python Selenium, Selenium Grid 4, Chrome/Firefox automation, pytest, the Page Object Model, failure artifacts, and a containerised CI pipeline.

## Project architecture

```text
selenium-lab/
├── app/                         # Flask TaskBoard system under test
│   ├── app.py
│   └── Dockerfile
├── scripts/                     # Stand-alone Selenium exercises
│   ├── first_session.py
│   ├── leak.py
│   ├── login_flow.py
│   ├── dynamic.py
│   ├── custom_wait.py
│   ├── raw_webdriver.sh
│   └── cleanup_leaks.sh
├── framework/
│   ├── pages/                   # Page Object Model and wait conditions
│   ├── tests/                   # pytest suites
│   ├── data/login_cases.csv     # Editable login test data
│   ├── conftest.py
│   ├── pytest.ini
│   ├── requirements.txt
│   └── Dockerfile
├── artifacts/                   # CI reports and screenshots
├── docker-compose.yml
├── run_ci.sh
└── validate.sh
```

## What you will practise

1. Build and containerise a Flask web application.
2. Deploy Selenium Grid 4 with a hub, Chrome node, and Firefox node.
3. Inspect Grid status and GraphQL, and send raw W3C WebDriver HTTP requests.
4. Create and release Remote WebDriver sessions.
5. Practise ID, NAME, CSS, XPath, and tag-name locators.
6. Use explicit waits, dropdowns, and JavaScript confirm dialogs.
7. Build a pytest suite with Page Objects, fixtures, parametrisation, and markers.
8. Capture screenshots and page source on failures; generate HTML and JUnit reports.
9. Run tests in parallel and package the runner in Docker.
10. Run a CI-style pipeline and a data-driven login challenge.

## Requirements

- Ubuntu 22.04 or a compatible Linux host
- Docker Engine and Docker Compose plugin
- Python 3.10+
- `curl`, `jq`, and `file`
- Approximately 4–8 GB RAM and 10 GB free disk for browser images
- Internet access for downloading Docker images and Python packages

## 1. Install host dependencies

```bash
sudo apt-get update
sudo apt-get install -y ca-certificates curl gnupg jq file python3-venv python3-pip
```

Install Docker using the official Docker Ubuntu repository instructions:
https://docs.docker.com/engine/install/ubuntu/

Then add your account to the Docker group and reconnect:

```bash
sudo usermod -aG docker "$USER"
# Log out and reconnect, then:
docker run --rm hello-world
docker compose version
```

## 2. Create a Python environment (for host-side exercises)

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install -r framework/requirements.txt
```

## 3. Download Selenium Grid images

```bash
docker pull selenium/hub:4.18.1-20240224
docker pull selenium/node-chrome:4.18.1-20240224
docker pull selenium/node-firefox:4.18.1-20240224
```

## 4. Start TaskBoard and Selenium Grid

```bash
docker compose up -d --build webapp selenium-hub chrome firefox
docker compose ps
```

Wait until Grid is ready and both browser nodes have registered:

```bash
for i in $(seq 1 60); do
  curl -sf http://localhost:4444/status | jq -e '.value.ready and (.value.nodes | length) == 2' >/dev/null && break
  sleep 2
done
curl -s http://localhost:4444/status | jq '.value | {ready, nodes}'
curl -s -X POST -H 'Content-Type: application/json' \
  --data '{"query":"{ grid { totalSlots sessionCount } }"}' \
  http://localhost:4444/graphql | jq
```

TaskBoard is available from the host at `http://localhost:5000`; the Grid UI/status endpoint is at `http://localhost:4444`.

**Important networking rule:** Selenium scripts running on the host use `http://localhost:4444` for Grid access. A browser running inside a Selenium container must open the app at `http://webapp:5000`, not `localhost:5000`.

## 5. Run the practical exercises in order

Activate the host virtual environment first:

```bash
source .venv/bin/activate
```

### Task 1 — Explore the application

```bash
curl -s http://localhost:5000/ | grep -E '<title>|<h1>'
curl -s http://localhost:5000/login | grep -E '<input|<button'
curl -s http://localhost:5000/healthz
```

Demo credentials: `admin` / `s3cret`. Each browser receives its own signed session cookie and its own task list.

### Task 2 — Raw WebDriver protocol

```bash
chmod +x scripts/raw_webdriver.sh
./scripts/raw_webdriver.sh
```

The script creates a Chrome session, navigates to TaskBoard, reads the page title, locates an element, and deletes the session.

### Task 3 — Remote sessions and screenshots

```bash
python scripts/first_session.py
file artifacts/home.png
```

To understand leaked sessions, deliberately run:

```bash
python scripts/leak.py
curl -s http://localhost:4444/status | jq \
  '[.value.nodes[].slots[] | select(.session != null)] | length'
./scripts/cleanup_leaks.sh
```

`leak.py` intentionally omits `driver.quit()`. Use it only for this exercise.

### Task 4 — Locator strategies

```bash
python scripts/login_flow.py
```

Expected key output includes the page heading `My Tasks`, user `admin`, two task rows, and the invalid-login message.

### Task 5 — Waits, dropdowns, and alerts

```bash
python scripts/dynamic.py
python scripts/custom_wait.py
```

`dynamic.py` demonstrates why an immediate lookup fails while the AJAX statistics are still `Loading...`, then uses `WebDriverWait`. It also selects a priority and dismisses/accepts the confirmation dialog.

Optional timeout failure exercise:

```bash
STATS_TIMEOUT=1 python scripts/dynamic.py
```

The short timeout is expected to raise `TimeoutException`.

### Task 6 — pytest and Page Object Model

```bash
cd framework
pytest --browser chrome -v
pytest --browser firefox -v
pytest --browser chrome -m smoke -q
cd ..
```

The `test_intentional_failure` test is skipped by default. It can be enabled for the artifact exercise in Task 7.

### Task 7 — Screenshots and reports

```bash
cd framework
FAIL_DEMO=1 pytest --browser chrome \
  --html=artifacts/report.html --self-contained-html \
  --junitxml=artifacts/junit.xml -q
```

This command is expected to exit non-zero because it deliberately asserts the wrong heading. Inspect the screenshot and DOM under `framework/artifacts/`. Then run a clean report:

```bash
pytest --browser chrome \
  --html=artifacts/report.html --self-contained-html \
  --junitxml=artifacts/junit.xml -q
```

Parallel execution:

```bash
pytest --browser chrome -n 2 -q
pytest --browser firefox -n 2 -q
```

### Task 8 — Containerised CI pipeline

Run the complete pipeline from the project root:

```bash
chmod +x run_ci.sh validate.sh
./run_ci.sh
```

By default, the pipeline runs a smoke gate and the full suite on Chrome and Firefox. Select only one browser if needed:

```bash
BROWSERS=firefox ./run_ci.sh
BROWSERS=chrome ./run_ci.sh
```

Reports are written to `artifacts/ci/`. The script prints a summary table and returns a non-zero exit code if a browser suite fails.

## 6. Data-driven login challenge

Edit `framework/data/login_cases.csv` to add or modify test cases. The included cases cover valid credentials, wrong password, unknown user, empty fields, case sensitivity, and surrounding whitespace.

Run only the CSV-driven tests:

```bash
cd framework
pytest --browser chrome -k login_data -v
```

The test IDs are generated from the CSV values so the output is readable.

## 7. Custom row-count wait challenge

The class `row_count_is` in `framework/pages/conditions.py` returns the matching elements only when exactly the requested number exists. The test `test_row_count_condition_for_three_added_tasks` adds three tasks and waits until the five total rows are present (two defaults plus three additions).

```bash
cd framework
pytest --browser chrome -k row_count_condition -v
```

## 8. Validate and troubleshoot

From the project root:

```bash
./validate.sh
```

Common issues:

| Symptom | Likely cause | Fix |
|---|---|---|
| Docker permission denied | Group change not active | Log out and reconnect; check `id -nG` |
| Grid connection refused | Hub not ready | Check `docker compose ps` and hub logs |
| Grid has no nodes | Event bus registration problem | Check `SE_EVENT_BUS_*` values and node logs |
| Browser cannot open app | Browser used `localhost` | Use `http://webapp:5000` inside the Compose network |
| `NoSuchElementException` | Wrong locator or element not rendered | Inspect DOM; use an explicit wait for dynamic elements |
| `TimeoutException` | Wait condition not met in time | Check the condition and realistic timeout |
| `UnexpectedAlertPresentException` | Alert is still open | Wait for `EC.alert_is_present()` and accept/dismiss it |
| `StaleElementReferenceException` | Page navigated or refreshed | Find the element again after navigation |
| `ModuleNotFoundError: pages` | pytest run from wrong directory | Run pytest from `framework/`; check `pytest.ini` |
| Browser crashes | Shared memory too small | Keep `shm_size: "1gb"` on browser nodes |
| CI artifacts owned by root | UID/GID not passed to test container | Use `run_ci.sh`, which exports host UID/GID |

## 9. Cleanup

```bash
docker compose --profile tests down --rmi local --remove-orphans
```

To remove local Python and generated report artifacts too:

```bash
rm -rf .venv artifacts/ci framework/artifacts
```

## Notes

- The Grid image tags and Python package versions follow the supplied lab handout.
- The demo credentials and Flask secret are for this isolated training lab only; do not reuse them in production.
- The Flask app stores task data in signed session cookies so independent test sessions do not share mutable server-side task state.
- Do not run the deliberate session-leak or failure-demo exercises against a production Grid.
